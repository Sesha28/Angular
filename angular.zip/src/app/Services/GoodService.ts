import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { ModelLogIn } from "../Model/Model";
@Injectable({
    providedIn: 'root'
})
export class GoodService {
    public j: number = 0;
    constructor() { }
    getJ() {
        this.j++;
        // alert("In Good Service\nJ = " + this.j)
    }
}

@Injectable({
    providedIn: 'root'
})
export class LoginGaurd implements CanActivate {
    constructor(private route57: Router) { }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        let isLoggedIn = ModelLogIn.isUserLoggedIn();
        if (!isLoggedIn) this.route57.navigate(['/LogIn'])
        return isLoggedIn;
    }
}
