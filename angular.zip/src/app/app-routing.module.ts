import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactComponent } from './Components/contact/contact.component';
import { HomeComponent } from './Components/home/home.component';
import { InfoComponent } from './Components/info/info.component';
import { LoginComponent } from './Components/login/login.component';
import { LoginGaurd } from './Services/GoodService';

//https://mdbootstrap.com/docs/standard/extended/login/
const routes: Routes = [
  { path: '', component: HomeComponent , canActivate:[LoginGaurd]},
  { path: 'Home', component: HomeComponent , canActivate:[LoginGaurd]},
  { path: 'About', component: InfoComponent   },
  { path: 'Contact', component: ContactComponent , canActivate:[LoginGaurd]},
  { path: 'LogIn', component: LoginComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }