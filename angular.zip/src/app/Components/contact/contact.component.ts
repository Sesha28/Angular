import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/Model/Model';
import { GoodService } from 'src/app/Services/GoodService';

declare var $: any;
declare var bootstrap: any;
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  isAscending = true;
  title: String = "In Contact Page";
  show: boolean = false;
  // Students:Array<String> = new Array<String>()
  Names: Array<String> = ["John", "Janni", "Jhanardhan"]
  PipeData: String = "A Few Good Men"
  rekha: Student = new Student(20, "rekha")
  students: Array<Student> = new Array<Student>();
  constructor(private gs:GoodService) {
    this.title = "In Constructor";
  }
  zulu(i) {
    i += 20;
    return " return from zulu function I = " + i
  }
  ngOnInit() {
    this.title = "This is on Load"
    // alert("j : " + GoodService.j++)
    // setTimeout((function(){
    //   alert("this will execute after 1000 milliseconds");
    //   this.title = "The Title changed"
    // }).bind(this),1000);

    this.gs.getJ()
    setTimeout(() => {
      this.title = "Fat arrow function"
    }, 1000)

    for (let i = 0; i < 10; ++i) {
      let s: Student = new Student(i, "Name_" + i)
      this.students.push(s);
    }
  }
  ButtonClick(e: any, str: String) {
    // alert("In Click\n" + str);
    this.show = !this.show;
  }
  WhatsTheName(e: any, theValue: String) {
    alert("In on change\nValue = " + e.target.value + "\nAngular value = " + theValue);
  }
  currentStudent: Student = null;//new Student(12,"Dummy");
  modal: any = null;
  RowClick(e: any, s: Student): void {
    //alert(JSON.stringify(s));
    this.currentStudent = s;
    //$("#exampleModal").modal('toggle');    
    // s.name = "Priyanka";

    var myModal = document.getElementById('exampleModal')
    this.modal = new bootstrap.Modal(myModal)
    this.modal.toggle();
  }
  SaveStudent(e: any, uname: String, age: number) {
    //Send the uname and age to back end  and receive a suucess or a failure
    setTimeout(() => {
      this.currentStudent.name = uname;
      this.currentStudent.age = age;
    }, 1000);
  }
  RowDelete($event, ind: number): void {
    this.students.splice(ind, 1);
  }
  ShowStudents(data: any) {
    return JSON.stringify(data, null, ' ');
  }
}

