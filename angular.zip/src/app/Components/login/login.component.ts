import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ModelLogIn, TheSubscriber } from 'src/app/Model/Model';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @Output() LoggedIn = new EventEmitter<boolean>()
  isLoggedIn: boolean = false;
  constructor(private route57: Router, private subscription: TheSubscriber) { }
  ngOnInit() {
  }

  // DoLogin(e: any) {
  // ModelLogIn.isLoggedIn = this.isLoggedIn = true
  // Check User credentials and decide if you need to call this.LoggedIn.emit(true);
  // sessionStorage.setItem("IsLoggedIn" , "true")
  // window.location.href = "/"
  //this.LoggedIn.emit(true);
  // }

  DoLogIn(e: any, uname: string, pwd: string) {
    // alert("User Name : " + uname +"\nPWD : " + pwd)
    e.preventDefault();
    // Send uname and pwd to server and await response
    ModelLogIn.LogInUser(uname);
    // HeaderComponent.hCom.uName = ModelLogIn.getuserName()
    this.subscription.TheUserJustLoggedIn()
    this.route57.navigate(['/'])
    // window.location.href = "/"
  }
}