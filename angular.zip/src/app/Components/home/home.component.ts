import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { PriceModel } from 'src/app/Model/Model';
import { AdvertisementComponent } from 'src/app/Reuse/advertisement/advertisement.component';
import { GoodService } from 'src/app/Services/GoodService';
import { ChildComponent } from '../child/child.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  theSubject: Subject<unknown> = null;

  @ViewChild(ChildComponent, { static: false }) TheActualChild: ChildComponent;
  @ViewChild(AdvertisementComponent, { static: false }) TheAdComponent: AdvertisementComponent;

  NowPriceModel: PriceModel = null;
  // constructor(private MyHTTPClient: HttpClient ) { }
  constructor(private gs:GoodService ) { }

  ngOnInit() {
    // alert("j : " + GoodService.j++)
    setInterval(() => {
      this.NowPriceModel = new PriceModel("Actual price : " + Math.round(Math.random() * 120000 + 50000) + "/-", "Price Now : " + Math.round(Math.random() * 12000 + 1000) + "/-")
    }, 3000);

    //if i can do this then the data can always come from an AJAX call.
    this.theSubject = new Subject();
    this.theSubject.next("102");
    this.gs.getJ();
    // let param = new HttpParams();
    // param = param.append("draw", "2");
    // param = param.append("pageSize", "100");
    // var url:string = "";
    // this.MyHTTPClient.get(url, {params:param}).
    // subscribe(
    //   jdata => { },
    //   error => { }
    // )
  }

  ngAfterViewInit() {
    let that = this;
    setTimeout(function () { that.theSubject.next(Math.round(Math.random() * 3000) + 1); }, 3000);
    //this.TheAdComponent.foo();
  }
  ClickAndFetch(e: any) {
    this.theSubject.next(Math.round(Math.random() * 3000) + 1);
  }
  BuyNowIntimation(e: PriceModel) {
    alert("Buy Now In Parent\n" + JSON.stringify(e))
  }
}
