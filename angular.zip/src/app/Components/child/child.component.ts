import { typeWithParameters } from '@angular/compiler/src/render3/util';
import { Component, Input, OnInit } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  theVal: string = "1000";
  //@Input() subject: any = null;
  @Input() subject: Subject<unknown> = null;
  constructor() { }
  ngOnInit() {
    let that = this;
    const sub1 = this.subject.subscribe(
      x => {
        that.theVal = String(x);
        // alert("In Child " + x);
      },
      err => alert(err.message)
    );
  }
  ngAfterViewInit() {
   
  }
  doSubscription() {

  }
}
