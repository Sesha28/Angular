import { Component, Input, OnInit } from '@angular/core';
import { ISubscribeForLoggedInEvents, ModelLogIn, TheSubscriber } from 'src/app/Model/Model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, ISubscribeForLoggedInEvents {

  static hCom: HeaderComponent = null;
  @Input('name') brand: string;
  uName: String = null;
  constructor(private subscription:TheSubscriber) { }

  ngOnInit() {
    // alert('Labamba')
    this.subscription.SubscribeMe(this)
    HeaderComponent.hCom = this;
    //this.uName = ModelLogIn.getuserName()
  }
  TheUserJustLoggedIn() {
    this.uName = ModelLogIn.getuserName()
  }
  TheUserJustLoggedOff() {
    // throw new Error("Method not implemented.");
    this.TheUserJustLoggedIn();
  }
  LogOff(e: any) {
    ModelLogIn.LogOff()
    this.subscription.TheUserJustLoggedOff()
    window.location.href = "/"
  }
}
