import { Component, OnInit } from '@angular/core';
import { Observable, Subject, from, interval, zip, ReplaySubject, of } from 'rxjs'
import { map } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {

  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    //   let mySubject = new Subject();
    //   mySubject.subscribe(x => alert(x));
    //   mySubject.next("102");
    //   alert('adding another next');
    //   mySubject.next("103");
    //   //************************************************************ * /
    //   const sub1 = mySubject.subscribe(
    //     x => alert(x),
    //     err => alert(err.message)
    //   );

    // of(1, 2, 3)
    // .pipe(map((x) => x * x))
    // .subscribe((v) => alert(`value: ${v}`));
    // }
    // alert(JSON.stringify(this.activatedRoute.queryParams.getValue('id')));
  }

}
