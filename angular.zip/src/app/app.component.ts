import { Component, OnInit } from '@angular/core';
import { ModelLogIn } from './Model/Model';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isLoggedIn:boolean = false;
  title = 'AngiBoy';
  constructor() { }
  ngOnInit() {
    //if(sessionStorage.getItem("IsLoggedIn") == "true" ) this.isLoggedIn = true

  }
  LoggedInIntimation(e:boolean){
    // alert(e)
    this.isLoggedIn = e;
  }
}