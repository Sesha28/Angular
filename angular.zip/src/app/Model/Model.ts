import { Injectable } from "@angular/core";

export class Student {
    name: String;
    age: number;
    constructor(age: number, name: String) { this.name = name; this.age = age; }
}

export class PriceModel {
    constructor(public ac: String, public op: String) { }
}
export class ModelLogIn {
    static isLoggedIn: boolean = false;
    static userName: String = null;
    static isUserLoggedIn(): boolean {
        if (sessionStorage.getItem("IsLoggedIn") === "true") ModelLogIn.isLoggedIn = true;
        else ModelLogIn.isLoggedIn = false;
        return ModelLogIn.isLoggedIn;
    }
    static LogInUser(uName: string) {
        ModelLogIn.userName = uName;
        sessionStorage.setItem("IsLoggedIn", "true");
        sessionStorage.setItem("uName", uName);
        ModelLogIn.isLoggedIn = true;
    }
    static getuserName() {
        if (ModelLogIn.userName == null) ModelLogIn.userName = sessionStorage.getItem("uName");
        if (ModelLogIn.userName) ModelLogIn.isLoggedIn = true;
        return ModelLogIn.userName;
    }
    static LogOff() {
        sessionStorage.clear();
        ModelLogIn.isLoggedIn = false;
        ModelLogIn.userName = null;
    }
}
export interface ISubscribeForLoggedInEvents {
    TheUserJustLoggedIn()
    TheUserJustLoggedOff()
}
@Injectable({
    providedIn: 'root'
})
export class TheSubscriber implements ISubscribeForLoggedInEvents {
    TheUserJustLoggedOff() {
        this.comps.forEach(comp => comp.TheUserJustLoggedOff)
    }
    comps: ISubscribeForLoggedInEvents[] = []
    TheUserJustLoggedIn() {        
        this.comps.forEach(comp => comp.TheUserJustLoggedIn())
    }
    SubscribeMe(comp: ISubscribeForLoggedInEvents) {
        let index: number = this.comps.indexOf(comp);
        if (index !== -1) return;
        this.comps.push(comp);
    }
    USubscribeMe(comp: ISubscribeForLoggedInEvents) {
        let index: number = this.comps.indexOf(comp);
        if (index == -1) return;
        this.comps.splice(index, 1)
    }
}