export class Student {
    name: String;
    age: number;
    constructor(age: number, name: String) { this.name = name; this.age = age; }
}

export class PriceModel {
    constructor(public ac: String, public op: String) { }
}
export class ModelLogIn {
    static isLoggedIn: boolean = false;
    static userName : String = ""
    static isUserLoggedIn(): boolean {        
         if (sessionStorage.getItem("IsLoggedIn") === "true") ModelLogIn.isLoggedIn = true;
        else ModelLogIn.isLoggedIn = false;
        return ModelLogIn.isLoggedIn;
    }
    static LogInUser(uName:String) {
        this.userName = uName;
        sessionStorage.setItem("IsLoggedIn" , "true");
        ModelLogIn.isLoggedIn = true;
    }
}