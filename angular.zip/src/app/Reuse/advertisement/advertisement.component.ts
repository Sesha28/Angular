import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PriceModel } from 'src/app/Model/Model';

@Component({
  selector: 'app-advertisement',
  templateUrl: './advertisement.component.html',
  styleUrls: ['./advertisement.component.css']
})
export class AdvertisementComponent implements OnInit {

  @Input("ap") actPrice: String = "Actual Price 0/-";
  @Input() op: String = "Offer Price 10/-";

  @Input() priceModel: PriceModel = null;

  @Output() BuyNow =  new EventEmitter<PriceModel>()

  constructor() { }
  ngOnInit() {
  }
  BuyNowClicked(e: any) {
    alert("Buy Now clicked in Ad. Component\n" + JSON.stringify(this.priceModel, null, " "))
    //make a call to google site to register a click, then redirect to the respective site.
    this.BuyNow.emit(this.priceModel)
  }
  foo(){
    alert("In foo of the Child Component");
  }
}
