import { Pipe, PipeTransform } from '@angular/core';
import { Student } from '../Model/Model';
@Pipe({ name: 'LaLaLand' })
export class LaLaPipe implements PipeTransform {
  transform(data: Student[], attribute: String, isAsc: boolean): Student[] {
    if (data === null || data === undefined || attribute == null || attribute == undefined) {
      return null;
    }
    // if (attribute === "Age" && isAsc === true){
    //   data.age *= 10;
    //   return data;
    // }
    let sortedArray =
      data.sort((a, b) => {
        if (a.age > b.age) return isAsc ? -1 : 1;
        else if (a.age < b.age) return isAsc ? 1 : -1;
        else return 0;
      })
    return sortedArray;
  }
}