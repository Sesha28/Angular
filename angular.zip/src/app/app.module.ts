import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Components/header/header.component';
import { ChildComponent } from './Components/child/child.component';
import { HomeComponent } from './Components/home/home.component';
import { InfoComponent } from './Components/info/info.component';
import { LaLaPipe } from './Pipes/LaLaPipe';
import { ContactComponent } from './Components/contact/contact.component';
import { AdvertisementComponent } from './Reuse/advertisement/advertisement.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './Components/login/login.component';
@NgModule({
  declarations: [
    AppComponent,
    InfoComponent,
    HeaderComponent,
    ChildComponent,
    HomeComponent,
    ContactComponent,
    LaLaPipe,
    AdvertisementComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
