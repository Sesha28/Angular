﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ForAngular.Models;
using System.Text.Json;

namespace ForAngular.Controllers
{
    public partial class HomeController : Controller
    {
        /// <summary>
        /// url : /Home/GetStudents
        /// </summary>
        /// <returns></returns>
        public String GetStudents()
        {
            //Request.Headers["isLoggedIn"]
            return
            JsonSerializer.Serialize(
            Enumerable.Range(0, 10).Select(i =>
             {
                 return new
                 {
                     name = "name_" + i,
                     age = i
                 };
             }).ToList());
        }
        /// <summary>
        /// url : /Home/LogInUser
        /// </summary>
        /// <returns></returns>
        public String LogInUser()
        {
            String userName = Request.Form["uName"];
            String pwd = Request.Form["pwd"];
            String what = Request.Headers["isLoggedIn"];

            if (userName.ToLower() == "rani") return "false";
            return "true";
        }
        /// <summary>
        /// url : /Home/MicCheck
        /// </summary>
        /// <returns></returns>
        public string MicCheck()
        {
            return "Hellow there";
        }
    }
}
